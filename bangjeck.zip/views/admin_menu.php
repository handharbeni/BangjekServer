<a href="<?php $config->base_url();?>frenchise.html">
	<div class="menu-link <?php if($page_adj=="frenchise"){echo "active-link";}?>">
		Frenchise
	</div>
</a>
<a href="<?php $config->base_url();?>gender.html">
	<div class="menu-link <?php if($page_adj=="gender"){echo "active-link";}?>">
		Gender
	</div>
</a>
<a href="<?php $config->base_url();?>global_setting.html">
	<div class="menu-link <?php if($page_adj=="global_setting"){echo "active-link";}?>">
		Global Setting
	</div>
</a>
<a href="<?php $config->base_url();?>jenis_transaksi.html">
	<div class="menu-link <?php if($page_adj=="jenis_transaksi"){echo "active-link";}?>">
		Jenis Transaksi
	</div>
</a>
<a href="<?php $config->base_url();?>kurir.html">
	<div class="menu-link <?php if($page_adj=="kurir"){echo "active-link";}?>">
		Kurir
	</div>
</a>
<a href="<?php $config->base_url();?>level.html">
	<div class="menu-link <?php if($page_adj=="level"){echo "active-link";}?>">
		Level
	</div>
</a>
<a href="<?php $config->base_url();?>merchant.html">
	<div class="menu-link <?php if($page_adj=="merchant"){echo "active-link";}?>">
		Merchant
	</div>
</a>
<a href="<?php $config->base_url();?>merchant_category.html">
	<div class="menu-link <?php if($page_adj=="merchant_category"){echo "active-link";}?>">
		Merchant Category
	</div>
</a>
<a href="<?php $config->base_url();?>merchant_menu.html">
	<div class="menu-link <?php if($page_adj=="merchant_menu"){echo "active-link";}?>">
		Merchant Menu
	</div>
</a>
<a href="<?php $config->base_url();?>merchant_menu_category.html">
	<div class="menu-link <?php if($page_adj=="merchant_menu_category"){echo "active-link";}?>">
		Merchant Menu Category
	</div>
</a>
<a href="<?php $config->base_url();?>pelanggan.html">
	<div class="menu-link <?php if($page_adj=="pelanggan"){echo "active-link";}?>">
		Pelanggan
	</div>
</a>
<a href="<?php $config->base_url();?>room_chat.html">
	<div class="menu-link <?php if($page_adj=="room_chat"){echo "active-link";}?>">
		Room Chat
	</div>
</a>
<a href="<?php $config->base_url();?>staff.html">
	<div class="menu-link <?php if($page_adj=="staff"){echo "active-link";}?>">
		Staff
	</div>
</a>
<a href="<?php $config->base_url();?>status_setting.html">
	<div class="menu-link <?php if($page_adj=="status_setting"){echo "active-link";}?>">
		Status Setting
	</div>
</a>
<a href="<?php $config->base_url();?>tarif.html">
	<div class="menu-link <?php if($page_adj=="tarif"){echo "active-link";}?>">
		Tarif
	</div>
</a>
<a href="<?php $config->base_url();?>transaksi.html">
	<div class="menu-link <?php if($page_adj=="transaksi"){echo "active-link";}?>">
		Transaksi
	</div>
</a>
