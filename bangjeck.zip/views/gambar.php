<html>
<head>
<title>BangJeck | Gambar</title>
<style>
body{
	background-image: url('<?php echo $url;?>');
	background-repeat: no-repeat;
	background-size: 100% auto;
	background-position: center;
	margin : 0px;
}
</style>
</head>
<body>
</body>
</html>